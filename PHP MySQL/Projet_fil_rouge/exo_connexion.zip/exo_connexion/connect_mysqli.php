<?php
    define('USER',"root");
    define('PASSWD',"");
    define('SERVER',"localhost");
    define('BASE',"achat_voiture");
?>